PIXEL SMP Rank Badges – Minecraft Java Edition

This pack adds seven custom rank badge glyphs for LuckTAB.

Suggested LuckTAB prefixes:
- "majitel;\ue000 ;;&4"
- "admin;\ue001 ;;&5"
- "moderator;\ue002 ;;&9"
- "helper;\ue003 ;;&b"
- "vipplus;\ue004 ;;&e"
- "vip;\ue005 ;;&6"
- "player;\ue006 ;;&a"

IMPORTANT:
1. This ZIP must be provided to Minecraft Java clients as a server resource pack.
2. The ZIP also needs to be configured as LuckTAB's local icon pack.
3. Bedrock/Geyser support is not guaranteed by this Java font pack and needs separate testing.
4. If the normal Minecraft font does not display correctly, the font fallback/provider format may need adjustment for the exact client version.
